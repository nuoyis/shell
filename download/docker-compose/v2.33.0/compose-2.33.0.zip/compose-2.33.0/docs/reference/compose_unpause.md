# docker compose unpause

<!---MARKER_GEN_START-->
Unpauses paused containers of a service

### Options

| Name        | Type   | Default | Description                     |
|:------------|:-------|:--------|:--------------------------------|
| `--dry-run` | `bool` |         | Execute command in dry run mode |


<!---MARKER_GEN_END-->

## Description

Unpauses paused containers of a service
