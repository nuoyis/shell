# docker compose pause

<!---MARKER_GEN_START-->
Pauses running containers of a service. They can be unpaused with `docker compose unpause`.

### Options

| Name        | Type   | Default | Description                     |
|:------------|:-------|:--------|:--------------------------------|
| `--dry-run` | `bool` |         | Execute command in dry run mode |


<!---MARKER_GEN_END-->

## Description

Pauses running containers of a service. They can be unpaused with `docker compose unpause`.