# docker compose scale

<!---MARKER_GEN_START-->
Scale services 

### Options

| Name        | Type   | Default | Description                     |
|:------------|:-------|:--------|:--------------------------------|
| `--dry-run` | `bool` |         | Execute command in dry run mode |
| `--no-deps` | `bool` |         | Don't start linked services     |


<!---MARKER_GEN_END-->

