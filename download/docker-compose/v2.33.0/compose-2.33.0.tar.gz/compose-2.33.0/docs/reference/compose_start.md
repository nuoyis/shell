# docker compose start

<!---MARKER_GEN_START-->
Starts existing containers for a service

### Options

| Name        | Type   | Default | Description                     |
|:------------|:-------|:--------|:--------------------------------|
| `--dry-run` | `bool` |         | Execute command in dry run mode |


<!---MARKER_GEN_END-->

## Description

Starts existing containers for a service
